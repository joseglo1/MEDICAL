<?php
class Asignarobra extends CI_Controller
{
  function index() 
  {
    $this->load->model('Compania_model');
    $this->load->model('Ciaobra_model');
    $valor_permiso = 9; 
    if($this->session->userdata('rolusuario') == 1) {
      $valor_permiso = 0; /// Super Usuario
    }
    $this->Acceso_model->autorizado();
    if($this->session->userdata('nombreu'))
    {
      $lacia = $this->session->userdata('idcia');
      $data['allobras'] = $this->Ciaobra_model->get_all_ciaobra2($lacia);
      $titulo['tit'] = "Asignar Obra";
      $titulo['tit2'] = "Debe seleccionar una obra";
      $this->load->view('plantB1');
      $this->load->view('plantB2',$titulo);
      if($valor_permiso==9) {
          $this->load->view('asignarobra/noacceso',$data);
      }
      else {
        $this->load->view('asignarobra/index',$data);
      }
      $this->load->view('plantB4');
    }
  }
}
?>