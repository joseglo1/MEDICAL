<?php
class Asignarcia extends CI_Controller
{
    function index()
    {
      $this->load->model('Compania_model');
      $valor_permiso = 9; 
      if($this->session->userdata('rolusuario') == 1) {
        $valor_permiso = 0; /// Super Usuario
      }
      $this->Acceso_model->autorizado();
      if($this->session->userdata('nombreu'))
      {
        $data['allcia'] = $this->Compania_model->get_all_compania();

        $titulo['tit'] = "Compañías";
        $titulo['tit2'] = "Consulta General";
        $titulo['vpermiso'] = $valor_permiso;
        $this->load->view('plantB1');
        $this->load->view('plantB2',$titulo);
        if($valor_permiso==9) {
          $this->load->view('asignarcia/noacceso',$data);
        }
        else {
          $this->load->view('asignarcia/index',$data);
        }
        $this->load->view('plantB4'); 
      }       
    }
    function asignar()
    {
      $this->load->model('Compania_model');
      $this->Acceso_model->autorizado(); 
      $titulo['tit'] = "Principal";
      $titulo['tit2'] = "Indicadores";
      
      if($this->session->userdata('nombreu'))
      { 
        if(isset($_POST) && count($_POST) > 0){
          $workidcia = $this->input->post('workcia');
          $lacia = $this->Compania_model->get_compania($workidcia);
          $cianame = $lacia['RazonSocial'];
        $this->session->set_userdata('myworkcia',$workidcia);
        $this->session->set_userdata('idcia',$workidcia);
        $this->session->set_userdata('nomcia',$cianame);
      }
      //$this->load->view('usuario/index');
      $this->load->view('plantB1');
      $this->load->view('plantB2',$titulo);
      $this->load->view('plantB3Content');
      $this->load->view('plantB4');    
    }
  }
}

?>